package com.example.ges_sports.ui.backend.ges_user

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.ges_sports.data.DataUserRepository
import com.example.ges_sports.models.User
import com.example.ges_sports.models.UserRoles

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun GesUserScreen(
    navController: NavHostController
) {

    val viewModel: GesUserViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return GesUserViewModel(DataUserRepository()) as T
            }
        }
    )

    val usuarios = viewModel.usuarios
    val filtroRol = viewModel.filtroRol
    val busqueda = viewModel.busqueda

    // Estados del diálogo
    var mostrarDialogo by remember { mutableStateOf(false) }
    var usuarioEditando by remember { mutableStateOf<User?>(null) }

    // Campos del formulario
    var campoNombre by remember { mutableStateOf("") }
    var campoEmail by remember { mutableStateOf("") }
    var campoPassword by remember { mutableStateOf("") }
    var campoRol by remember { mutableStateOf("ADMIN_DEPORTIVO") }

    fun abrirCrear() {
        usuarioEditando = null
        campoNombre = ""
        campoEmail = ""
        campoPassword = ""
        campoRol = "ADMIN_DEPORTIVO"
        mostrarDialogo = true
    }

    fun abrirEditar(user: User) {
        usuarioEditando = user
        campoNombre = user.nombre
        campoEmail = user.email
        campoPassword = user.password
        campoRol = user.rol
        mostrarDialogo = true
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Gestión de usuarios") })
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { abrirCrear() },
                containerColor = Color.Black,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Añadir")
            }
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // 🟦 BARRA DE BÚSQUEDA
            OutlinedTextField(
                value = busqueda,
                onValueChange = { viewModel.cambiarBusqueda(it) },
                label = { Text("Buscar por nombre o email") },
                leadingIcon = { Icon(Icons.Default.Search, "Buscar") },
                modifier = Modifier.fillMaxWidth()
            )

            // 🟦 CHIPS DE ROLES
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = filtroRol == null,
                    onClick = { viewModel.seleccionarRol(null) },
                    label = { Text("TODOS") },
                    border = null,
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Color.DarkGray,
                        selectedContainerColor = Color.Black,
                        labelColor = Color.White,
                        selectedLabelColor = Color.White
                    )
                )

                UserRoles.allRoles.forEach { (clave, etiqueta) ->
                    FilterChip(
                        selected = filtroRol == clave,
                        onClick = { viewModel.seleccionarRol(clave) },
                        label = { Text(etiqueta) },
                        border = null,
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color.DarkGray,
                            selectedContainerColor = Color.Black,
                            labelColor = Color.White,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // 🟦 LISTA DE USUARIOS
            if (usuarios.isEmpty()) {
                Box(
                    Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No hay usuarios. Pulsa + para añadir.")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(usuarios) { user ->
                        TarjetaUsuario(
                            user,
                            onEditar = { abrirEditar(it) },
                            onBorrar = { viewModel.borrarUsuario(it) }
                        )
                    }
                }
            }
        }
    }

    // 🟦 DIÁLOGO CREAR / EDITAR
    if (mostrarDialogo) {
        AlertDialog(
            onDismissRequest = { mostrarDialogo = false },
            title = { Text(if (usuarioEditando == null) "Nuevo usuario" else "Editar usuario") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = campoNombre, onValueChange = { campoNombre = it }, label = { Text("Nombre") })
                    OutlinedTextField(value = campoEmail, onValueChange = { campoEmail = it }, label = { Text("Email") })
                    OutlinedTextField(
                        value = campoPassword,
                        onValueChange = { campoPassword = it },
                        label = { Text("Contraseña") },
                        visualTransformation = PasswordVisualTransformation()
                    )

                    Text("Rol:")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        UserRoles.allRoles.forEach { (clave, etiqueta) ->
                            FilterChip(
                                selected = campoRol == clave,
                                onClick = { campoRol = clave },
                                label = { Text(etiqueta) },
                                border = null
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (campoNombre.isNotBlank() && campoEmail.isNotBlank() && campoPassword.isNotBlank()) {

                        if (usuarioEditando == null) {
                            viewModel.crearUsuario(campoNombre, campoEmail, campoPassword, campoRol)
                        } else {
                            viewModel.editarUsuario(
                                usuarioEditando!!.copy(
                                    nombre = campoNombre,
                                    email = campoEmail,
                                    password = campoPassword,
                                    rol = campoRol
                                )
                            )
                        }
                        mostrarDialogo = false
                    }
                }) {
                    Text("Guardar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogo = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun TarjetaUsuario(
    usuario: User,
    onEditar: (User) -> Unit,
    onBorrar: (User) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            // Avatar con inicial
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    usuario.nombre.first().uppercase(),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(usuario.nombre, style = MaterialTheme.typography.titleMedium)
                Text(usuario.email, style = MaterialTheme.typography.bodySmall)
                Text(usuario.rol, color = MaterialTheme.colorScheme.primary)
            }

            IconButton(onClick = { onEditar(usuario) }) {
                Icon(Icons.Default.Edit, contentDescription = "Editar")
            }

            IconButton(onClick = { onBorrar(usuario) }) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar")
            }
        }
    }
}
