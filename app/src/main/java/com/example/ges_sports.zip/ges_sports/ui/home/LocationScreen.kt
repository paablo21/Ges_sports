package com.example.ges_sports.ui.home

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.google.android.gms.location.LocationServices

// Coordenadas del Centro Multideporte de Jacarilla, Alicante
private const val CENTRO_LAT = 38.0894
private const val CENTRO_LNG = -0.9954
private const val CENTRO_NOMBRE = "Centro Multideporte Jacarilla"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationScreen(navController: NavHostController) {
    val context = LocalContext.current

    // Estado de la ubicación del usuario
    var latitudUsuario by remember { mutableStateOf<Double?>(null) }
    var longitudUsuario by remember { mutableStateOf<Double?>(null) }
    var mensajeEstado by remember { mutableStateOf("Pulsa el botón para obtener tu ubicación") }
    var permisoState by remember { mutableStateOf("PENDIENTE") } // PENDIENTE / CONCEDIDO / DENEGADO

    val fusedLocationClient = remember {
        LocationServices.getFusedLocationProviderClient(context)
    }

    // Launcher para solicitar permiso ACCESS_FINE_LOCATION
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            permisoState = "CONCEDIDO"
            mensajeEstado = "Permiso concedido. Obteniendo ubicación..."
            obtenerUbicacion(fusedLocationClient) { lat, lng ->
                latitudUsuario = lat
                longitudUsuario = lng
                mensajeEstado = "Ubicación obtenida correctamente"
            }
        } else {
            permisoState = "DENEGADO"
            mensajeEstado = "Permiso denegado. No se puede acceder a tu ubicación."
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                },
                title = { Text("Localización", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                modifier = Modifier.background(
                    Brush.verticalGradient(listOf(Color(0xFF0288D1), Color(0xFF01579B)))
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .background(Brush.verticalGradient(listOf(Color(0xFF0288D1), Color(0xFF000000))))
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            // ── TARJETA: UBICACIÓN DEL CENTRO ──
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color(0xFF64B5F6),
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            "Centro Multideporte",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Text("Jacarilla, Alicante", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
                    Text(
                        "Lat: $CENTRO_LAT  ·  Lng: $CENTRO_LNG",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                    // Botón abrir Google Maps con el centro
                    Button(
                        onClick = {
                            val uri = Uri.parse("geo:$CENTRO_LAT,$CENTRO_LNG?q=$CENTRO_LAT,$CENTRO_LNG($CENTRO_NOMBRE)")
                            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                                setPackage("com.google.android.apps.maps")
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("Ver en Google Maps", color = Color.White)
                    }
                }
            }

            // ── TARJETA: MI UBICACIÓN ──
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color(0xFF81C784),
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            "Mi ubicación",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }

                    // Estado del permiso y coordenadas
                    Text(mensajeEstado, color = when (permisoState) {
                        "CONCEDIDO" -> Color(0xFF81C784)
                        "DENEGADO"  -> Color(0xFFEF9A9A)
                        else        -> Color.White.copy(alpha = 0.7f)
                    }, fontSize = 13.sp)

                    // Coordenadas si las tenemos
                    if (latitudUsuario != null && longitudUsuario != null) {
                        Text(
                            "Lat: %.6f".format(latitudUsuario),
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                        Text(
                            "Lng: %.6f".format(longitudUsuario),
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }

                    // Botón solicitar permiso / obtener ubicación
                    if (permisoState != "DENEGADO") {
                        Button(
                            onClick = {
                                permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A047))
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (permisoState == "CONCEDIDO") "Actualizar mi ubicación"
                                else "Obtener mi ubicación",
                                color = Color.White
                            )
                        }
                    } else {
                        // Si denegó, mostrar opción para ir a ajustes
                        Text(
                            "Para usar esta función, activa el permiso de ubicación en Ajustes > Aplicaciones > GesSports.",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

// ── Función para obtener la última ubicación conocida ──
@SuppressLint("MissingPermission")
fun obtenerUbicacion(
    fusedLocationClient: com.google.android.gms.location.FusedLocationProviderClient,
    onLocation: (Double, Double) -> Unit
) {
    fusedLocationClient.lastLocation.addOnSuccessListener { location ->
        location?.let {
            onLocation(it.latitude, it.longitude)
        }
    }
}