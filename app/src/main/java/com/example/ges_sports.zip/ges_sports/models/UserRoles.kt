package com.example.ges_sports.models

object UserRoles {
    val allRoles = listOf(
        "ADMIN_DEPORTIVO" to "Admin",
        "ENTRENADOR"      to "Entrenador",
        "ARBITRO"         to "Árbitro",
        "JUGADOR"         to "Jugador"
    )
}