package com.example.ges_sports.data

import com.example.ges_sports.models.User
import com.example.ges_sports.repository.UserRepository

class ApiUserRepository: UserRepository {
    override suspend fun getAllUsers(): List<User> {
        TODO("Not yet implemented")
    }

    override suspend fun getUsersByRole(rol: String): List<User> {
        TODO("Not yet implemented")
    }

    override suspend fun getUserById(id: Int): User? {
        TODO("Not yet implemented")
    }

    override suspend fun addUser(user: User): User {
        TODO("Not yet implemented")
    }

    override suspend fun updateUser(user: User): Boolean {
        TODO("Not yet implemented")
    }

    override suspend fun deleteUser(user: User): Boolean {
        TODO("Not yet implemented")
    }
}