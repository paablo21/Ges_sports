package com.example.ges_sports.ui.backend.ges_user

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ges_sports.models.User
import com.example.ges_sports.models.UserRoles

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormUserScreen(
    navController: NavHostController,
    viewModel: GesUserViewModel,
    userId: Int
) {
    // 🔧 Buscamos el usuario en la lista del ViewModel (si existe, estamos editando)
    val usuarioEditando = viewModel.users.firstOrNull { it.id == userId }

    // Inicializamos los campos con los datos del usuario (si edita) o vacíos (si crea)
    var nombre by rememberSaveable { mutableStateOf(usuarioEditando?.nombre ?: "") }
    var email by rememberSaveable { mutableStateOf(usuarioEditando?.email ?: "") }
    var password by rememberSaveable { mutableStateOf(usuarioEditando?.password ?: "") }
    var rol by rememberSaveable { mutableStateOf(usuarioEditando?.rol ?: "JUGADOR") }

    // 🔧 Para mostrar errores de validación
    var errorMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                // 🔧 El título cambia según si creamos o editamos
                title = {
                    Text(
                        if (usuarioEditando == null) "Nuevo usuario" else "Editar usuario",
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                ),
                modifier = Modifier.background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF0288D1),
                            Color(0xFF01579B)
                        )
                    )
                )
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF0288D1),
                            Color(0xFF000000)
                        )
                    )
                )
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            // NOMBRE
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre", color = Color.White) },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0x22000000),
                    unfocusedContainerColor = Color(0x22000000),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    cursorColor = Color.White
                )
            )

            // EMAIL
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email", color = Color.White) },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0x22000000),
                    unfocusedContainerColor = Color(0x22000000),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    cursorColor = Color.White
                )
            )

            // CONTRASEÑA
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña", color = Color.White) },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0x22000000),
                    unfocusedContainerColor = Color(0x22000000),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    cursorColor = Color.White
                )
            )

            // ROL
            Text("Rol", color = Color.White)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                UserRoles.allRoles.forEach { (clave, etiqueta) ->
                    FilterChip(
                        selected = rol == clave,
                        onClick = { rol = clave },
                        label = { Text(etiqueta) },
                        shape = RoundedCornerShape(12.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color(0xFF1A1A1A).copy(alpha = 0.5f),
                            selectedContainerColor = Color.White,
                            labelColor = Color.White,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            // 🔧 Mensaje de error si los campos están vacíos
            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color(0xFFFF6B6B)
                )
            }

            Spacer(Modifier.height(8.dp))

            // 🔧 BOTÓN GUARDAR — ahora distingue entre crear y editar
            Button(
                onClick = {
                    // Validación básica
                    if (nombre.isBlank() || email.isBlank() || password.isBlank()) {
                        errorMessage = "Todos los campos son obligatorios"
                        return@Button
                    }

                    if (usuarioEditando == null) {
                        // 🔧 CREAR: id = 0 para que Room lo autogenere
                        val nuevoUsuario = User(
                            id = 0,
                            nombre = nombre,
                            email = email,
                            password = password,
                            rol = rol
                        )
                        viewModel.addUser(nuevoUsuario)
                    } else {
                        // 🔧 EDITAR: usamos el mismo id del usuario que estábamos editando
                        val usuarioActualizado = User(
                            id = usuarioEditando.id,
                            nombre = nombre,
                            email = email,
                            password = password,
                            rol = rol
                        )
                        viewModel.updateUser(usuarioActualizado)
                    }

                    navController.popBackStack() // volver a la lista
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3F5AA9),
                    contentColor = Color.White
                )
            ) {
                // 🔧 El texto del botón también cambia según la acción
                Text(if (usuarioEditando == null) "Crear usuario" else "Guardar cambios")
            }
        }
    }
}