package com.example.ges_sports.domain

import com.example.ges_sports.data.LoginRepository
import com.example.ges_sports.models.User

class LogicLogin {

    // Comprueba email y contraseña
    fun comprobarLogin(email: String, password: String): User {

        if (email.isBlank() || password.isBlank()) {
            throw IllegalArgumentException("Los campos no pueden estar vacíos")
        }

        // Busca un usuario que coincida
        val usuario = LoginRepository.obtenerUsuarios()
            .find { it.email == email && it.password == password }
            ?: throw IllegalArgumentException("Email o contraseña incorrectos")

        return usuario
    }
}
