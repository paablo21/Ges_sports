package com.example.ges_sports.ui.backend.ges_equipo

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ges_sports.models.Equipo
import com.example.ges_sports.models.User
import com.example.ges_sports.repository.EquipoRepository
import com.example.ges_sports.repository.UserRepository
import kotlinx.coroutines.launch

class GesEquipoViewModel(
    val equipoRepository: EquipoRepository,
    val userRepository: UserRepository
) : ViewModel() {

    private var _equipos by mutableStateOf<List<Equipo>>(emptyList())
    val equipos: List<Equipo> get() = _equipos

    private var _entrenadores by mutableStateOf<List<User>>(emptyList())
    val entrenadores: List<User> get() = _entrenadores

    private var _todosUsuarios by mutableStateOf<List<User>>(emptyList())

    // Solo jugadores disponibles (sin equipo o del equipo actual)
    fun jugadoresDisponibles(equipoId: Int): List<User> =
        _todosUsuarios.filter {
            it.rol == "JUGADOR" && (it.equipoId == -1 || it.equipoId == equipoId)
        }

    // Jugadores que ya pertenecen a un equipo concreto
    fun jugadoresDeEquipo(equipoId: Int): List<User> =
        _todosUsuarios.filter { it.equipoId == equipoId }

    init {
        viewModelScope.launch {
            equipoRepository.getAllEquipos().collect { _equipos = it }
        }
        viewModelScope.launch {
            userRepository.getUsersByRole("ENTRENADOR").collect { _entrenadores = it }
        }
        viewModelScope.launch {
            userRepository.getAllUsers().collect { _todosUsuarios = it }
        }
    }

    fun addEquipo(equipo: Equipo) {
        viewModelScope.launch { equipoRepository.addEquipo(equipo) }
    }

    fun updateEquipo(equipo: Equipo) {
        viewModelScope.launch { equipoRepository.updateEquipo(equipo) }
    }

    fun deleteEquipo(equipo: Equipo) {
        viewModelScope.launch { equipoRepository.deleteEquipo(equipo.id) }
    }

    // Asigna jugadores al equipo actualizando su equipoId
    fun asignarJugadores(
        equipoId: Int,
        seleccionados: List<User>,
        anteriores: List<User>
    ) {
        viewModelScope.launch {
            // Desasignar los que ya no están
            anteriores
                .filter { ant -> seleccionados.none { it.id == ant.id } }
                .forEach { userRepository.updateUser(it.copy(equipoId = -1)) }
            // Asignar los nuevos
            seleccionados.forEach { jugador ->
                userRepository.updateUser(jugador.copy(equipoId = equipoId))
            }
        }
    }

    // Para equipos recién creados: espera a que aparezca en la lista y luego asigna
    fun asignarJugadoresNuevoEquipo(nombreEquipo: String, seleccionados: List<User>) {
        viewModelScope.launch {
            var intentos = 0
            var equipo = _equipos.firstOrNull { it.nombre == nombreEquipo }
            while (equipo == null && intentos < 10) {
                kotlinx.coroutines.delay(150)
                equipo = _equipos.firstOrNull { it.nombre == nombreEquipo }
                intentos++
            }
            equipo?.let { e ->
                seleccionados.forEach { jugador ->
                    userRepository.updateUser(jugador.copy(equipoId = e.id))
                }
            }
        }
    }
}